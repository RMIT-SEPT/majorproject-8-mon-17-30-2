# Back-end Skeleton Coding

Assigned members: Danny, Joshua
Completed on: Aug 9, 2020 10:00 PM
Created: Aug 3, 2020 6:00 PM
DOD: Adheres to the Back-End System/Database design, and builds and compiles successfully.
Due date: Aug 7, 2020
Priority: P2
Sprint: Sprint 1
Status: Awaiting QA
Story/Effort Points: 8 hrs

Coding of the uml diagram from design

- Just classes and method skeletons (parameters too maybe) so you know how the class interact with eachother
- Methods can be left blank
- As long as it can compile