# Design of back-end system/database

Assigned members: Danny
Completed on: Aug 5, 2020 5:00 PM
Created: Aug 3, 2020 5:59 PM
DOD: System designed to specifications, UML diagram for all classes
Due date: Aug 5, 2020
Priority: P1 🔥
Sprint: Sprint 1
Status: Awaiting QA
Story/Effort Points: 3 hrs

Uml diagram for backend

uml diagram for entire assignment

Design of database 

All classes involved and how they interact to each other