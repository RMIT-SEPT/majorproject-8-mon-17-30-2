# Login API

Assigned members: Austin
Created: Aug 3, 2020 6:02 PM
DOD: Code reviewed by back-end team members, No bugs, code compiles, acceptance criteria are met, validation for login
Due date: Aug 14, 2020
Priority: P3
Sprint: Sprint 1
Status: Awaiting QA
Story/Effort Points: 8 hrs

Generic api for both customers and admin