# Registration API - Customer

Assigned members: Joshua
Completed on: Aug 13, 2020 11:00 AM
Created: Aug 3, 2020 6:02 PM
DOD: Passes acceptance tests for [data storage of new account], validation for registration
Due date: Aug 12, 2020
Priority: P3
Sprint: Sprint 1
Status: Awaiting QA
Story/Effort Points: 5hrs