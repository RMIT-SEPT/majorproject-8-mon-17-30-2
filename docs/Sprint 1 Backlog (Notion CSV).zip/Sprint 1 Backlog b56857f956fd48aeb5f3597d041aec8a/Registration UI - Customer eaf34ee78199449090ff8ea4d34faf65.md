# Registration UI - Customer

Assigned members: Daniel
Created: Aug 3, 2020 6:00 PM
DOD: [Forms accepting name, username, email, password], submit button,
Due date: Aug 12, 2020
Priority: P4
Sprint: Sprint 1
Status: Awaiting QA
Story/Effort Points: 4 hrs

Basic html form