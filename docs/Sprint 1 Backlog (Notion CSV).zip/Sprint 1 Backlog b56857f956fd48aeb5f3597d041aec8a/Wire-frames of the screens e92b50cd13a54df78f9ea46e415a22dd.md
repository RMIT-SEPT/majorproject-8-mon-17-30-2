# Wire-frames of the screens

Assigned members: Daniel
Completed on: Aug 5, 2020 7:00 AM
Created: Aug 3, 2020 5:59 PM
DOD: All potential screens designed with basic layout, approved by team members
Due date: Aug 5, 2020
Priority: P1 🔥
Sprint: Sprint 1
Status: Awaiting QA
Story/Effort Points: 3 hrs

Home page

Login Page

Registration

All pages